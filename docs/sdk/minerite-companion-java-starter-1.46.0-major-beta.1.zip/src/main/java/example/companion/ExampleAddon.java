package example.companion;

import fr.minerite.companion.api.CompanionAddon;
import fr.minerite.companion.api.CompanionApi;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class ExampleAddon implements CompanionAddon {
    @Override public void initialize(CompanionApi api) {
        var module = api.register(new CompanionApi.Definition("mining-notes", "Carnet Java", "HUD et écran créés par une extension Java", new ItemStack(Items.WRITABLE_BOOK), true));
        var visible = module.toggle("visible", "Afficher le HUD", "Compteur local de blocs observés par Companion", true);
        var x = module.number("position-x", "Position horizontale", "Coordonnées de l’interface", 240, 0, 1920);
        var y = module.number("position-y", "Position verticale", "Coordonnées de l’interface", 100, 0, 1080);
        var note = module.text("note", "Note", "Texte enregistré avec ce module", "Ma session de minage");
        module.hud(frame -> {
            if (!visible.get()) return;
            var session = api.snapshot(CompanionApi.Data.SESSION).getAsJsonObject();
            int blocks = session.has("blocks") ? session.get("blocks").getAsInt() : 0;
            int left = x.get().intValue(), top = y.get().intValue();
            frame.graphics().fill(left, top, left + 210, top + 38, 0xCC14171C);
            frame.graphics().text(api.client().font, note.get(), left + 10, top + 7, 0xFFFFFFFF, false);
            frame.graphics().text(api.client().font, "Blocs : " + blocks, left + 10, top + 22, 0xFFE7B35A, false);
        });
        Runnable open = () -> {
            Screen parent = api.client().gui.screen();
            module.openScreen(() -> new NotesScreen(parent, note));
        };
        module.key("key.keyboard.f8", open);
        module.action("Ouvrir le carnet", "Écran natif · raccourci F8", open);
        module.onEnable(() -> module.notify("Carnet activé"));
        module.onDisable(() -> System.getLogger("Companion example").log(System.Logger.Level.INFO, "Carnet désactivé"));
    }
    private static final class NotesScreen extends Screen {
        private final Screen parent;
        private final CompanionApi.Setting<String> note;
        NotesScreen(Screen parent, CompanionApi.Setting<String> note) { super(Component.literal("Carnet Java")); this.parent=parent; this.note=note; }
        @Override protected void init() {
            addRenderableWidget(Button.builder(Component.literal("Effacer la note"), button -> note.set("")).bounds(width/2-100,height/2,200,20).build());
            addRenderableWidget(Button.builder(Component.literal("Retour"), button -> onClose()).bounds(width/2-100,height/2+28,200,20).build());
        }
        @Override public void extractRenderState(GuiGraphicsExtractor graphics,int mouseX,int mouseY,float delta) {
            graphics.fill(0,0,width,height,0xE0101218);
            graphics.text(font,note.get(),width/2-100,height/2-25,0xFFFFFFFF,false);
            super.extractRenderState(graphics,mouseX,mouseY,delta);
        }
        @Override public void onClose() { minecraft.gui.setScreen(parent); }
        @Override public boolean isPauseScreen() { return false; }
    }
}
