# Extension Java pour Minerite Companion

Projet de départ pour l’API Java v1 en préparation avec Companion 1.46.0-major-beta.1. Il ne fonctionne pas avec la version stable 1.45.0. Le code source privé du Companion n’est pas nécessaire.

1. Installez un JDK 25.
2. Téléchargez le SDK Java correspondant à votre version de Minecraft depuis https://plugins.voidwake.fr/minerite-companion/java-api et placez le JAR dans `libs/`.
3. Choisissez `minecraft_version=26.2` ou `26.3` dans `gradle.properties`.
4. Compilez avec `gradlew.bat build` sous Windows, ou `./gradlew build` sous Linux/macOS.
5. Installez le JAR produit dans `build/libs/` dans le dossier `mods/` de votre profil Fabric, avec Fabric API et une version compatible de Companion. Redémarrez Minecraft.

Le SDK est une dépendance `compileOnly` : ne le placez pas dans `mods/` et ne l’embarquez pas dans votre extension. Le client fournit l’API à l’exécution. Pour `runClient`, placez un JAR compatible du Companion dans le dossier `run/mods/` de ce projet.

Le module « Carnet Java » apparaît dans Extensions et dans la liste des modules. F8 ouvre un écran natif ; les réglages et les actions sont disponibles dans sa fiche. Modifiez l’identifiant Fabric, le package, le nom du projet et vos informations avant publication.

## Point d’entrée

Déclarez votre classe `CompanionAddon` dans `entrypoints.minerite-companion` de `fabric.mod.json`. Companion appelle `initialize(CompanionApi)` après le démarrage du client. L’identifiant d’extension vient du conteneur Fabric, pas d’une chaîne choisie dans votre code. Déclarez modules, réglages et actions dans cette méthode ; les abonnements peuvent ensuite être fermés avec `Subscription.close()`.

## Cycle de vie

`module.enabled()` représente le choix du joueur. `module.active()` tient aussi compte des erreurs et du contrôle administratif des extensions. Les callbacks enregistrés avec `on`, `every`, `hud` et `key` sont exécutés uniquement quand le module est actif. `onDisable` s’exécute après son arrêt : libérez-y vos ressources. Une exception arrête le module concerné jusqu’au prochain lancement.

Les réglages sont enregistrés automatiquement dans `config/minerite-companion/java-addons/settings.json`. `api.configDirectory()` fournit un dossier distinct pour vos propres fichiers. Toutes les opérations de l’API se font sur le thread client ; utilisez `api.execute(...)` depuis une tâche en arrière-plan et vérifiez `module.active()` avant d’agir si le résultat appartient à un module.

## Code natif

Vous pouvez utiliser les API Minecraft et Fabric, des ressources, des modèles et des mixins. Ces composants ne sont pas déchargés par Companion. Un événement Fabric ou un mixin indépendant doit vérifier `module.active()` avant d’agir et prévoir son propre nettoyage. Le mode développeur ne rend pas Java isolé : un JAR a les mêmes accès qu’un autre mod Fabric. Ne lancez pas de traitement lent sur le thread client.

Cette préversion permet l’installation manuelle des extensions Java dans `mods/`. Le catalogue à installation immédiate concerne les extensions Lua ; la distribution de JAR approuvés dans le catalogue nécessite un parcours avec redémarrage.

Guide et référence : https://plugins.voidwake.fr/minerite-companion/java-api
