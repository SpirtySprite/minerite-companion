package fr.minerite.companion.api;

@FunctionalInterface
public interface CompanionAddon {
    void initialize(CompanionApi api) throws Exception;
}
