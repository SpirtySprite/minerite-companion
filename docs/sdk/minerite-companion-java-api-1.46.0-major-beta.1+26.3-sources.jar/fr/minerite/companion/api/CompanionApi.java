package fr.minerite.companion.api;

import com.google.gson.JsonElement;
import java.nio.file.Path;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.function.BooleanSupplier;
import java.util.function.DoubleSupplier;
import java.util.function.DoubleConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.item.ItemStack;

public interface CompanionApi {
    int VERSION = 1;
    String ENTRYPOINT = "minerite-companion";
    int apiVersion();
    String addonId();
    String minecraftVersion();
    Minecraft client();
    Path configDirectory();
    JsonElement snapshot(Data kind);
    Ui ui();
    Module register(Definition definition);
    void execute(Runnable callback);

    enum Data { PLAYER, WORLD, TARGET, HELD, INVENTORY, SESSION, COUNTERS }
    enum Event { TICK, JOIN, LEAVE, CHAT, ACTIONBAR, INVENTORY_CHANGED, HELD_ITEM_CHANGED, BLOCK_MINED, SESSION_CHANGED, COUNTERS_CHANGED }
    enum SettingType { BOOLEAN, NUMBER, TEXT }

    record Definition(String id, String name, String description, ItemStack icon, boolean enabledByDefault) {}
    record HudFrame(GuiGraphicsExtractor graphics, int width, int height) {}
    record Appearance(String theme, String layout, String cardStyle, String accent) {}
    record Colors(int text, int muted, int accent, int border) {}

    interface Ui {
        Colors colors();
        void text(GuiGraphicsExtractor graphics, String text, int x, int y, int width, float scale, int color, boolean bold);
        void panel(GuiGraphicsExtractor graphics, int x, int y, int width, int height, int color);
        Screen settingsScreen(Screen parent, String title, String subtitle, Consumer<SettingsPage> content);
    }

    interface SettingsPage {
        void group(String title);
        void info(String title, String help, Supplier<String> value);
        void action(String title, String help, Supplier<String> value, Runnable callback);
        void toggle(String title, String help, BooleanSupplier value, Runnable callback);
        void number(String title, String help, DoubleSupplier value, double minimum, double maximum, String suffix, DoubleConsumer change);
        void text(String title, String help, Supplier<String> value, Consumer<String> change);
    }

    interface Subscription extends AutoCloseable {
        @Override void close();
    }

    interface Setting<T> {
        String id();
        String name();
        String description();
        SettingType type();
        T defaultValue();
        T get();
        void set(T value);
        double minimum();
        double maximum();
    }

    interface Module {
        String id();
        boolean enabled();
        boolean active();
        String status();
        void enabled(boolean value);
        Setting<Boolean> toggle(String id, String name, String description, boolean initial);
        Setting<Double> number(String id, String name, String description, double initial, double minimum, double maximum);
        Setting<String> text(String id, String name, String description, String initial);
        Subscription on(Event event, Consumer<JsonElement> callback);
        Subscription every(int ticks, Runnable callback);
        Subscription hud(Consumer<HudFrame> callback);
        Subscription key(String translationKey, Runnable callback);
        Subscription onEnable(Runnable callback);
        Subscription onDisable(Runnable callback);
        Subscription onSettingChanged(Consumer<Setting<?>> callback);
        void action(String name, String description, Runnable callback);
        void openScreen(Supplier<? extends Screen> screen);
        void appearance(Appearance appearance);
        void notify(String message);
        boolean command(String command);
    }
}
