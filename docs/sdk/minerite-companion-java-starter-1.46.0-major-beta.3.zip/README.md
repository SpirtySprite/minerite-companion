# Extension Java pour Minerite Companion

Projet de départ pour l’API Java v1 en préparation avec Companion 1.46.0-major-beta.3. Il ne fonctionne pas avec la version stable 1.45.0. Le code source privé du Companion n’est pas nécessaire.

1. Installez un JDK 25.
2. Téléchargez le SDK Java correspondant à votre version de Minecraft depuis https://plugins.voidwake.fr/minerite-companion/java-api et placez le JAR dans `libs/`.
3. Choisissez `minecraft_version=26.2` ou `26.3` dans `gradle.properties`.
4. Compilez avec `gradlew.bat build` sous Windows, ou `./gradlew build` sous Linux/macOS.
5. Installez le JAR produit dans `build/libs/` dans le dossier `mods/` de votre profil Fabric, avec Fabric API et une version compatible de Companion. Redémarrez Minecraft.

Le SDK est une dépendance `compileOnly` : ne le placez pas dans `mods/` et ne l’embarquez pas dans votre extension. Le client fournit l’API à l’exécution. Pour `runClient`, placez un JAR compatible du Companion dans le dossier `run/mods/` de ce projet.

Le module « Carnet Java » apparaît dans Extensions et dans la liste des modules. F8 ouvre un écran natif ; les réglages et les actions sont disponibles dans sa fiche. Modifiez l’identifiant Fabric, le package, le nom du projet et vos informations avant publication.

## Point d’entrée

Déclarez votre classe `CompanionAddon` dans `entrypoints.minerite-companion` de `fabric.mod.json`. Companion appelle `initialize(CompanionApi)` après le démarrage du client. L’identifiant d’extension vient du conteneur Fabric, pas d’une chaîne choisie dans votre code. Déclarez modules, réglages et actions dans cette méthode ; les abonnements peuvent ensuite être fermés avec `Subscription.close()`.

## Cycle de vie

`module.enabled()` représente le choix du joueur. `module.active()` tient aussi compte des erreurs et du contrôle administratif des extensions. Les callbacks enregistrés avec `on`, `every`, `hud` et `key` sont exécutés uniquement quand le module est actif. `onDisable` s’exécute après son arrêt : libérez-y vos ressources. Une exception arrête le module concerné jusqu’au prochain lancement.

Les réglages sont enregistrés automatiquement dans `config/minerite-companion/java-addons/settings.json`. `api.configDirectory()` fournit un dossier distinct pour vos propres fichiers. Toutes les opérations de l’API se font sur le thread client ; utilisez `api.execute(...)` depuis une tâche en arrière-plan et vérifiez `module.active()` avant d’agir si le résultat appartient à un module.

## Code natif

Vous pouvez utiliser les API Minecraft et Fabric, des ressources, des modèles et des mixins. Ces composants ne sont pas déchargés par Companion. Un événement Fabric ou un mixin indépendant doit vérifier `module.active()` avant d’agir et prévoir son propre nettoyage. Le mode développeur ne rend pas Java isolé : un JAR a les mêmes accès qu’un autre mod Fabric. Ne lancez pas de traitement lent sur le thread client.

Cette préversion permet l’installation manuelle des extensions Java dans `mods/`. Le catalogue à installation immédiate concerne les extensions Lua ; la distribution de JAR approuvés dans le catalogue nécessite un parcours avec redémarrage.

Guide et référence : https://plugins.voidwake.fr/minerite-companion/java-api


## Propriété des modules et personnalisation visuelle

L’API expose uniquement les contrôles de vos propres modules. Un identifiant local identique à celui d’un module intégré reste dans votre espace de noms ; il ne le remplace pas. Les données reçues par `snapshot` sont copiées. Modifier, remplacer, activer ou désactiver les modules intégrés ou ceux d’une autre extension n’est pas un point d’extension pris en charge.

Les thèmes et dispositions HUD restent autorisés. `module.hudLayout(Map<HudWidget,HudPlacement>)` applique des positions normalisées et une échelle aux panneaux existants, sans changer leur visibilité, leurs données ou leur comportement. L’API copie votre carte, conserve les réglages personnels et retire les remplacements à la désactivation. `api.ui().hudLayout()` retourne une copie non modifiable des positions effectives. Les panneaux automatiques sont absents. Le dernier module actif enregistré gagne en cas de conflit. L’éditeur HUD continue à modifier la disposition personnelle, sans les remplacements temporaires. Le projet propose un réglage de démonstration désactivé par défaut.

L’API publique se trouve dans `fr.minerite.companion.api`. N’utilisez pas les classes privées `kiru.swing.*`, la réflexion ou des mixins pour modifier le comportement des modules existants. Un JAR Java n’est pas isolé : cette règle est vérifiée lors de la revue d’une extension proposée, elle ne constitue pas une protection technique contre du code natif arbitraire.


## Identifiant Fabric

La dépendance officielle du client est `minerite_companion` (`CompanionApi.MOD_ID`). Le client fournit l’ancien identifiant uniquement comme alias pour les anciennes extensions. Les anciens JAR du Companion doivent être remplacés manuellement une première fois lors de cette migration ; ne conservez pas les deux versions dans `mods/`. Les fichiers de réglages historiques restent lus et conservés.


## Icônes avant la connexion

Utilisez `CompanionApi.Definition.item(..., "minecraft:writable_book", ...)` pour déclarer une icône sans créer de pile au démarrage. Les composants des objets ne sont pas encore liés à ce moment-là dans Minecraft 26.2/26.3. La pile est construite uniquement lors du rendu en jeu. L’ancien constructeur avec ItemStack reste disponible pour la compatibilité binaire, mais votre code ne doit pas créer de pile personnalisée avant le chargement des données du monde.
