local notebook = companion.module {
    id = "notebook",
    name = "Carnet de session",
    description = "Suivez un objectif personnel et consultez votre carnet avec F7."
}

notebook:setting { id = "visible", name = "Afficher le carnet sur le HUD", type = "boolean", default = true }
notebook:setting { id = "goal", name = "Objectif de blocs", type = "number", default = 1000, min = 100, max = 100000 }
notebook:setting { id = "pos_x", name = "Position horizontale", type = "number", default = 240, min = 0, max = 1900 }
notebook:setting { id = "pos_y", name = "Position verticale", type = "number", default = 100, min = 0, max = 1000 }
notebook:setting { id = "note", name = "Note personnelle", type = "text", default = "Bonne session !" }

local blocks = 0
local earnings = "0"
local goalReached = false

notebook:every(20, function()
    local session = companion.session()
    blocks = session.blocks or 0
    earnings = session.earnings or "0"
    if blocks >= notebook:get("goal") and not goalReached then
        companion.notify("Objectif atteint : " .. blocks .. " blocs minés !")
        goalReached = true
        notebook:store("best_blocks", math.max(blocks, notebook:store("best_blocks") or 0))
    end
    if blocks < notebook:get("goal") then goalReached = false end
end)

notebook:hud(function(draw)
    if not notebook:get("visible") then return end
    local x = math.min(notebook:get("pos_x"), math.max(0, draw.width - 194))
    local y = math.min(notebook:get("pos_y"), math.max(0, draw.height - 66))
    draw:panel(x, y, 194, 66, "DD15171C")
    draw:text(x + 10, y + 9, "Carnet de session", "E7B35A")
    draw:text(x + 10, y + 25, blocks .. " / " .. notebook:get("goal") .. " blocs")
    draw:bar(x + 10, y + 42, 174, 3, blocks / notebook:get("goal"), "E7B35A")
    draw:text(x + 10, y + 52, "F7 : ouvrir le carnet", "9B9FA8")
end)

notebook:bind("key.keyboard.f7", function()
    notebook:open("Mon carnet", function(ui)
        ui:label("Blocs minés : " .. blocks)
        ui:label("Gains observés : " .. earnings)
        ui:label(notebook:get("note"))
        ui:button("Enregistrer ce résultat", function()
            notebook:store("best_blocks", math.max(blocks, notebook:store("best_blocks") or 0))
            companion.notify("Résultat enregistré dans votre carnet.")
        end)
    end)
end)
